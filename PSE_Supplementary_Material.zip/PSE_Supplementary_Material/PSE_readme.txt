# Supplementary Material: 15-Prime S-Unit Equation & p-adic Lattices
**Associated Manuscript:** Subverting the Dimensionality Curse in the 15-Prime S-Unit Equation via p-adic Lattice Enumeration and Composite Fusions.
**Author:** Chun Wing Lai (Master of Philosophy, Chinese University of Hong Kong)

## Overview
This archive contains the C++17 bare-metal framework and Python Orchestrator used to empirically validate the Orthogonal Sub-Lattice Isolation lemma and the Minkowski Lattice Inflation trap detailed in the manuscript. The geometric search boundaries are strictly aligned with the theoretical absolute Baker-Davenport limits (X <= 500).

## System Requirements
* **OS:** Linux (Ubuntu/Debian recommended), macOS, or WSL
* **Compiler:** GCC (`g++`) with strictly `C++17` support
* **Libraries:** GNU Multiple Precision (`libgmp-dev`), Fast Precision LLL (`libfplll-dev`)
* **Python:** 3.8+

## Installation (Ubuntu/Debian)
A setup script is provided to quickly configure the academic environment:
```bash
chmod +x setup.sh
sudo ./setup.sh
